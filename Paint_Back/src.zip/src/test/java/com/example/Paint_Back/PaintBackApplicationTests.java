package com.example.Paint_Back;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaintBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
